//
//  ViewControllerThree.swift
//  To Do
//
//  Created by Daniel Barton on 12/7/20.
//

import UIKit

class ViewControllerThree: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
   
           }
    
    override func viewDidAppear(_ animated: Bool) {
        
      //  swipeOutlet?.isHidden = UserDefaults.standard.bool(forKey: "showSwipeLabel");
        
       // pressOutlet?.isHidden = UserDefaults.standard.bool(forKey: "showPressLabel");

    }

    @IBAction func showHelpersAct(_ sender: Any) {
  
     //   UserDefaults.standard.set(false, forKey: "showSwipeLabel");
        
    //    UserDefaults.standard.set(false, forKey: "showPressLabel");
        
       // addOutlet?.isHidden = false;
        
        UserDefaults.standard.set(false, forKey: "addLabel");
        
       // var swipeAddVC = ViewController.swipeOutlet
        
        
        //retrieveValueFromVC.isHidden = false;
        
        UserDefaults.standard.set(false, forKey: "swipeLabel");
        
        UserDefaults.standard.set(false, forKey: "pressLabel");
        
        UserDefaults.standard.set(false, forKey: "introLabel");
        
  //     swipeOutlet?.isHidden = false;
        
    //   pressOutlet?.isHidden = false;
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
