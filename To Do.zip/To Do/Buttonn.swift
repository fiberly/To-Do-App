//
//  Buttonn.swift
//  To Do
//
//  Created by Daniel Barton on 8/6/20.
//

import UIKit

class Buttonn : UIButton {
    
   override func awakeFromNib() {
        super.awakeFromNib();
        self.layer.cornerRadius = 15;
    
    
    
    
}
}

