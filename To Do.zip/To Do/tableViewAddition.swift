//
//  tableViewAddition.swift
//  To Do
//
//  Created by Daniel Barton on 8/10/20.
//

import UIKit

class tableViewAddition: UIViewController {


    
   //  var text = "";
      
  //     var text2 = "";
    //var added3:String = "";
    
    
   // var tableView = self().added3
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // addOutlet.addGestureRecognizer(UITapGestureRecognizer(coder: UITapGestureRecognizer)!);
        
      //  performSegue(withIdentifier: "seguedContent", sender: self)
        
        // Do any additional setup after loading the view.
       // addOutlet?.text = text;
        
        self.setupForLabelTapped();
        
    }
   
    /*
    @IBOutlet weak var showHelpersOutlet: UIButton!
  
    
    @IBAction func showHelpers(_ sender: Any) {
        
       // addOutlet?.isHidden = false;
        
        UserDefaults.standard.set(false, forKey: "addLabel");
        
       // var swipeAddVC = ViewController.swipeOutlet
        
        
        //retrieveValueFromVC.isHidden = false;
        
        UserDefaults.standard.set(false, forKey: "swipeLabel");
        
        UserDefaults.standard.set(false, forKey: "pressLabel");
        
    }
    */
    
  /*  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
        if segue.identifier == "tableViewAdditionVC" {
        
             var sendToAddVC = segue.destination as? ViewController
            
            sendToAddVC?.swipeOutlet?.isHidden = true;
            
            sendToAddVC?.pressOutlet?.isHidden = true;
        
            //sendToAddVC = showHelpersOutlet;
        }
    }
*/
    
    override func viewDidAppear(_ animated: Bool) {
        
      //  let ViewControllerToAddVC: ViewController = ViewController(nibName: nil, bundle: nil);
        
     //   var retrieveValueFromVC = ViewControllerToAddVC.swipeOutlet?.isHidden;
        
        addOutlet?.isHidden = UserDefaults.standard.bool(forKey: "addLabel");
        
        
     //   retrieveValueFromVC = UserDefaults.standard.bool(forKey: "swipeLabel");
        
        
    }
    
    @objc func addLabelTapped(_ sender: UITapGestureRecognizer) {
        
        addOutlet.isHidden = true;
        
        UserDefaults.standard.set(true, forKey: "addLabel");
        
     //   self.addOutlet.isHidden = true;
        
        print("the add label has been tapped");
        
       // UserDefaults.standard.setValue(addOutlet, forKey: "labelSaving");
        
       // UserDefaults.standard.setValue(<#T##value: Any?##Any?#>, forKey: <#T##String#>)
        
    }
    
    func setupForLabelTapped() {
        
        let addLabelTap = UITapGestureRecognizer(target: self, action: #selector(self.addLabelTapped(_:)));
        
        self.addOutlet?.isUserInteractionEnabled = true;
        
        self.addOutlet?.addGestureRecognizer(addLabelTap);
        
    }
    
       @IBOutlet weak var addOutlet: UILabel!
    
    
    
    
    
    @IBOutlet weak var textField: UITextField!
    
    typealias ItemAddedCallback = () -> Void
    
    var doingACallback: ItemAddedCallback?;
    

    @IBAction func saveButton(_ sender: Any) {
      
        
        
        //...
        
        var listedCells: [String];
        
         
        let savedToDo = UserDefaults.standard.object(forKey: "ThingAdded");
         
         
         
       //  var listedCellss: [String];
         
      /*
         if let savedToList = savedToDo as? [String] {

             
             listedCellss = savedToList;
             
             listedCellss.append(textField.text!);
             
            // self.ViewTable?.reloadData();
             print(listedCells);
         } else {
             listedCellss = [textField.text!];
           //  added.append()
             //self.ViewTable?.reloadData();
         }
        */
        
         if let savedUpdated = savedToDo as? [String] {
             
             listedCells = savedUpdated;
             
             listedCells.append(textField.text!);
             
             print(listedCells);
             
             //self.tableView?.reloadData();
            
            
            
         } else {
            
             listedCells = [textField.text!];
             
             //self.tableView?.reloadData();
             
         }
         
         UserDefaults.standard.set(listedCells, forKey: "ThingAdded");
             
             // var savedToTheList:NSMutableArray = [];
             
             //tableView? = savedToList
             
            // added = savedToDo as? String
             
           //  listedCells.addObject(from: [textField.text!]);
            
             
             
          //   cells.text = savedToList
           
        
             
             
             
         
         
         
         //textField.text! == tableView?
    //     var returns = textField.text;
         
       //  textField.text! == tableView
        
         //let additions = segue.source as! tableViewAddition
         
         
         
         
         /*   if let table = tableView {
             print(table);
         }
      */
        // performSegue(withIdentifier: "endSegue", sender: nil)
         
       // let theView = segue.source as! tableViewAddition
         
      //  added2 = theView.name
         
             // if segue.identfier == "endSegue" {
             //added3 = added2.text!
         
         
         
        // let controlled = segue.destinationViewController as! tabkeViewAddition
         
        // returns = transfer
         
         //UserDefaults.standard.set(textField.text!, forKey: "ThingAdded")
         
      /*   if textField >= 1 {
             saveOutputButton.isHidden = false;
         } else {
             saveOutputButton.isHidden = true;
         }
      */
         
        /* if textField.text isEqualToString: @"" == TRUE {
             saveOutputButton setEnabled: NO
         }
         */
         
         
         
   /*      if textField.text!.isEmpty {
             saveOutputButton.isHidden = true;
         } else {
             saveOutputButton.isHidden = false;
             
         }
         
    */
         
       /*  if var field = textField.text {
             print(field);
             
            // added.append(contentsOf: added);
            
            // added.append(added3);
          
             
         }
      */
      /*   if added == textField.text {
             added.append(added3)
         }
         
         */
         
    /*     if (textField.text != nil) {
             textField.text = "";
         }
     */
        
         textField.text = "";
        
        // added.append(added2);
         
         // ViewTable?.reloadData()
         
        // ViewTable?.reloadData()
        
         
       //  self.ViewTable.reloadData();
         
         
        // self.tableView?.reloadData();
        // [self.tableView.reloadData()];
         
       //  theClass.tableView?.reloadData();
     
       
   
       
        doingACallback?();
        
    
        }
    
    
        
    override   func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       self.view.endEditing(true);
      
   }
   

  public     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           
           return true;
       
       
  }
    @IBOutlet weak var hideHelpersOutlet: UIButton!
    
    @IBAction func hideHelpers(_ sender: Any) {
        
    //    let hide: () = addOutlet.isHidden = true;
    //    let savedLabel = UserDefaults.standard;
       
      //  let saveLabel: Bool = addOutlet.isHidden == true;
        
       // var savedText = (addOutlet.text!);
        
       // savedText? = true;
        
       // savedLabel.string(forKey: "theSavedLabel");
  
        /*      if addOutlet.isHidden == true {
            
       }
 */
        
 //       performSegue(withIdentifier: "sendOutlets", sender: nil);
        
        addOutlet.isHidden = true;
        
       // UserDefaults.standard.object(forKey: String(saveLabel));
        
        hideHelpersOutlet.isHidden = true;
        
            }
    
    /*
     
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
     
    */
    


}
