//
//  ViewController.swift
//  To Do
//
//  Created by Daniel Barton on 8/1/20.
//
// upside down rotation
import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    
 /*
    var text:String = "";
 
    @IBAction func onButtonTap()
    
    {
        
        let tabVieAdd = labelDisapearControllerView(nibName: "labelDisapearControllerView", bundle: nil);
        
        tabVieAdd.text = "hey";
        
        navigationController?.pushViewController(tabVieAdd, animated: true);
        
    }
    
    */
    
    
   // let theClass = ViewController.self;
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let seguedController = segue.destination as? tableViewAddition {
            
            seguedController.doingACallback = {
                //self.tableView.reloadData();
               
             //   self.hideTwoOutlet =
                
             //   let pressHide = self.pressOutlet.isHidden = true;
                
                   //  let tbHide = self.tableViewOutlet.isHidden = true;
                
           //     let swipeHide = self.swipeOutlet.isHidden = true;
                
            }
            
            //self.tableView.reloadData()
        
        }
    }
    
    
    
   /* lazy var refreshData: UIRefreshControl = {
        let dataRefresh = UIRefreshControl();
        dataRefresh.addTarget(self, action: #selector(dataRequest), for: .valueChanged)
       
       // self.tableView.reloadData();
        
        return dataRefresh;
        
        
        
        
    }()
    
   
    */
    //UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource
    
  /*  private var refreshPuller = UIRefreshControl();
    
    private func addingPullToRefreshToTableView() {
        
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refreshPuller;
        } else {
            tableView.addSubview(refreshPuller);
        }
        
        refreshPuller.addTarget(self, action: #selector(refresh))
        
        
    }
    */
    
    
    
    var listedCells: [String] = []
   
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //self.ViewTable.reloadData();
        
       return listedCells.count
   
    }
   
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        
        
        let cells = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "TDList");
        
   
        //according to the video, this should prevent app from crashing, gives blank row instead of crash
        /*
         var emptyString = "";
         
         if let theText = cells.textLabel?.text = added[indexPath.row] as? String {
           
           emptyString = theText
        }
   */
        
        
        
        cells.textLabel?.text = listedCells[indexPath.row]
        
        
            // self.tableView.reloadData();
        
        return cells
        
        
        
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.cellForRow(at: indexPath)?.accessoryType = UITableViewCell.AccessoryType.checkmark;
        
        let checkedCell = listedCells[indexPath.row];
       // checkedCell.completed = !checkedCell.completed
       // checkedCell[indexPath.row] = checkedCell;
        
        
        
    }
   
    
    
    
    // var added = [String]()
    
   // var added2: String = "";
    //var added3: String = "";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     //   self.tableView.reloadData();
       
    
       // tableView?.refreshControl = UIRefreshControl();
    
        
        tableView?.delegate = self;
        tableView?.dataSource = self;
        
        
       
        
      //  let tblVA = ViewController();
        
      //  tblVA.text = "peach & pear";
        
     //   swipeOutlet.addGestureRecognizer(onButtonTap())
        
        
        
        
}
    
    @objc func swipeLabelTapped(_ sender: UITapGestureRecognizer) {
        
        
        
        self.swipeOutlet?.isHidden = true;
        
        UserDefaults.standard.set(true, forKey: "swipeLabel");
        
        print("the swipe to delete label was tapped");
        
        
       // swipeOutlet?.isHidden = UserDefaults.standard.bool(forKey: "swipeLabel");
        
     //   UserDefaults.standard.set(swipeLabelTapped(swipeOutlet), forKey: "LabelHide");
        
        
      // UserDefaults.standard.set(hideSwipe, forKey: "savelabel");
    }
    
    @objc func pressLabelTapped(_ sender: UITapGestureRecognizer) {
       
       self.pressOutlet?.isHidden = true;
        
        print("the press to go to vc2 label was tapped");
        
        UserDefaults.standard.set(true, forKey: "pressLabel");
        
       // pressOutlet?.isHidden = UserDefaults.standard.bool(forKey: "pressLabel");
        
       // UserDefaults.standard.setValue(pressOutlet, forKey: "labelSaving");
        
    }
    
  //  navigationController?.pushViewController(tableViewAddition, animated: true);
  

    @objc func introLabelOutGR(_ sender: UITapGestureRecognizer) {
        
        self.introLabelOut?.isHidden = true;
        
        print("intro label tapped");
        
        UserDefaults.standard.set(true, forKey: "introLabel");
        
    }

    
    func setupForLabelTapped() {
        
        let swipeLabelTap = UITapGestureRecognizer(target: self, action: #selector(self.swipeLabelTapped(_:)));
        
        self.swipeOutlet?.isUserInteractionEnabled = true;
        
        self.swipeOutlet?.addGestureRecognizer(swipeLabelTap);
        
        
        
        let pressLabelTap = UITapGestureRecognizer(target: self, action: #selector(self.pressLabelTapped(_:)));
        
        self.pressOutlet?.isUserInteractionEnabled = true;
        
        self.pressOutlet?.addGestureRecognizer(pressLabelTap);
        
        
        
        let introLabelTap = UITapGestureRecognizer(target: self, action: #selector(self.introLabelOutGR(_:)));
        
        self.introLabelOut?.isUserInteractionEnabled = true;
        
        self.introLabelOut?.addGestureRecognizer(introLabelTap);
        
        
        
    }
    
  /*
    @objc
    func dataRequest() {
        
        
        let endRefresh = DispatchTime.now() + .milliseconds(400);
        DispatchQueue.main.asyncAfter(deadline: endRefresh) {
           
            self.refreshData.beginRefreshing();
            
            self.refreshData.endRefreshing();
        }
        
        //self.tableView.reloadData();
       
        print("the refresh puller works");
        
        refreshData.endRefreshing();
       
        //self.tableView?.reloadData();
        
        self.tableViewOutlet.reloadData();
        
    }
    
    */
    
    
    @IBOutlet weak var introLabelOut: UILabel!
    
   
    override func viewDidAppear(_ animated: Bool) {
          
            // allows for the pull to refresh with older ios versions
           // listedCells = ["Mollie", "Melvin"];
  /*          if #available(iOS 10.0, *) {
                tableView?.refreshControl = refreshData;
            } else {
                tableView?.addSubview(refreshData);
            }
 */
           // refreshPuller.addTarget(self, action: #selector(refresh))
            
            
        
            
            
            textField?.clearButtonMode = .always;
            textField?.clearButtonMode = .whileEditing;
            
            
            
            let savedToDo = UserDefaults.standard.object(forKey: "ThingAdded")
            
            if let savedToList = savedToDo as? [String] {
                
                
                listedCells = savedToList;
                
                
             //   self.tableView.reloadData();
               
                /* func savedLabelHide() {
                  
                    UserDefaults.standard.object(forKey: "LabelHide");
               
                }
               // let savedLabelHide =
                    
                if let savedHide = savedLabelHide as? [String] {
                    
                    setupForLabelTapped() == savedLabelHide()
                    
                }
                */
        }
            
            self.setupForLabelTapped();
            
          //  performSegue(withIdentifier: "tableViewAdditionVC", sender: self);
           
          //  let savedLabel = UserDefaults.standard.object(forKey: "saveLabel");
            
        /*
             if let saveHideLabel = savedLabel {
                
                setupForLabelTapped() = saveHideLabel as! ()
                
            }
             
            */
           
            swipeOutlet?.isHidden = UserDefaults.standard.bool(forKey: "swipeLabel");
            
            pressOutlet?.isHidden = UserDefaults.standard.bool(forKey: "pressLabel");
           
            introLabelOut?.isHidden = UserDefaults.standard.bool(forKey: "introLabel");
        
        
        
           // swipeOutlet?.isHidden = UserDefaults.standard.bool(forKey: "swipeLabel");
           
           // pressOutlet?.isHidden = UserDefaults.standard.bool(forKey: "pressLabel");
         
        // addOutlet?.isHidden = UserDefaults.standard.bool(forKey: "addLabel");
       
        
            //tableView?.reloadData();
        
            self.tableViewOutlet?.reloadData();
        
            
}
        
  
   // let saveLabel = UserDefaults.standard;
    
   // saveddLabel.setObject("save label", forKey: "label");
            
   // if let savedLabel = saveddLabel.forKey("label") {
        
   // }
        
        
        
    @IBOutlet weak var tableViewOutlet: UITableView!
    
        //GOAL: append added with the value of the textField
        
        
    
   // var added: String = "";
    
    
    
     

        //savedToList
    
    //var transfer = textField.text
    
     func tableView(_ tableView: UITableView, commit deleteSlider: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if deleteSlider == UITableViewCell.EditingStyle.delete {
            
            listedCells.remove(at: indexPath.row);
          // tableView.deleteRows(at: [indexPath], with: .fade)
        
            tableView.reloadData();
                   
            UserDefaults.standard.set(listedCells, forKey: "ThingAdded");
            
        }
        
        //else if deleteSlider == .insert {
            
            
       
        
        
    }
    
   
    
    
    
    
    /* override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        if segue.identifier == "doneSegue" {
            added2 = textField.text!
        }
    }
    */
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var textField: UITextField!
    
    
    
    
    
/*    @IBAction func saveButton(_ sender: Any?) {
       
        
        
        let savedToDo = UserDefaults.standard.object(forKey: "ThingAdded")
        
        
        
      //  var listedCellss: [String];
        
     /*
        if let savedToList = savedToDo as? [String] {

            
            listedCellss = savedToList;
            
            listedCellss.append(textField.text!);
            
           // self.ViewTable?.reloadData();
            print(listedCells);
        } else {
            listedCellss = [textField.text!];
          //  added.append()
            //self.ViewTable?.reloadData();
        }
       */
        if let savedUpdated = savedToDo as? [String] {
            
            listedCells = savedUpdated;
            
            listedCells.append(textField.text!);
            
            print(listedCells);
            
            //self.tableView?.reloadData();
            
        } else {
           
            listedCells = [textField.text!];
            
            //self.tableView?.reloadData();
            
        }
        
        UserDefaults.standard.set(listedCells, forKey: "ThingAdded");
            
            // var savedToTheList:NSMutableArray = [];
            
            //tableView? = savedToList
            
           // added = savedToDo as? String
            
          //  listedCells.addObject(from: [textField.text!]);
           
            
            
         //   cells.text = savedToList
          
            
            
            
            
        
        
        
        //textField.text! == tableView?
   //     var returns = textField.text;
        
      //  textField.text! == tableView
       
        //let additions = segue.source as! tableViewAddition
        
        
        
        
        /*   if let table = tableView {
            print(table);
        }
     */
       // performSegue(withIdentifier: "endSegue", sender: nil)
        
      // let theView = segue.source as! tableViewAddition
        
     //  added2 = theView.name
        
            // if segue.identfier == "endSegue" {
            //added3 = added2.text!
        
        
        
       // let controlled = segue.destinationViewController as! tabkeViewAddition
        
       // returns = transfer
        
        //UserDefaults.standard.set(textField.text!, forKey: "ThingAdded")
        
     /*   if textField >= 1 {
            saveOutputButton.isHidden = false;
        } else {
            saveOutputButton.isHidden = true;
        }
     */
        
       /* if textField.text isEqualToString: @"" == TRUE {
            saveOutputButton setEnabled: NO
        }
        */
        
        
        
  /*      if textField.text!.isEmpty {
            saveOutputButton.isHidden = true;
        } else {
            saveOutputButton.isHidden = false;
            
        }
        
   */
        
      /*  if var field = textField.text {
            print(field);
            
           // added.append(contentsOf: added);
           
           // added.append(added3);
         
            
        }
     */
     /*   if added == textField.text {
            added.append(added3)
        }
        
        */
        
   /*     if (textField.text != nil) {
            textField.text = "";
        }
    */
        textField.text = "";
       // added.append(added2);
        
        // ViewTable?.reloadData()
        
       // ViewTable?.reloadData()
       
        
      //  self.ViewTable.reloadData();
        
        
        self.tableView?.reloadData();
       // [self.tableView.reloadData()];
        
      //  theClass.tableView?.reloadData();
    }
    
    */

    
//    @IBOutlet weak var saveOutputButton: UIButton!
    
    @IBOutlet weak var hideTwoOutlet: UIButton!
    /*
    @IBAction func hideTwo(_ sender: Any) {
      
        pressOutlet.isHidden = true;
      
        swipeOutlet.isHidden = true;
        
        hideTwoOutlet.isHidden = true;
        
    }
    
  */
    
    @IBOutlet weak var pressOutlet: UILabel!
    
    @IBOutlet weak var swipeOutlet: UILabel!
    
// right handed and left handed mode
    
 //   pressOutlet.isHidden = true;
    
   // swipeOutlet.isHidden = true;
   // weak var delegate: tableViewAddition?;

}
