//
//  ContentView.swift
//  To Do
//
//  Created by Daniel Barton on 9/21/25.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Item.creationDate, order: .reverse) private var items: [Item]
    // holds the string the character enters into a text field
    @State private var newTaskName: String = ""
    var body: some View {
        // more simple than navigationsplitview
        NavigationView {
            //vstack aranges view vertically
            VStack {
                HStack {
                    // Input Section -------------------------------------------------------------
                    // text field where user inputs a task
                    // $ is used to create a binding, tying the entered information to the newTaskName variable
                    TextField("Enter task that needs being done.", text: $newTaskName)
                        .textFieldStyle(.roundedBorder)
                    Button(action: addItem) {
                        Label("Add", systemImage: "plus.circle.fill")
                            .font(.title2)
                    }
                    //disables button if text field is blank
                    .disabled(newTaskName.isEmpty)
                    
                    
                } // end HStack
                .padding()
                
                // List Section --------------------------------------------------------------
                List {
                    ForEach(items) { item in
                        // places button and text side by side
                        HStack(spacing: 15) {
                            // This button toggles completion status
                            Button(action: {
                                item.isCompleted.toggle()
                            }) {
                                // image changes based upon completion status
                                Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(item.isCompleted ? .green : .gray)
                            }
                            .buttonStyle(.plain) // plain to ensure blending in with the row is smooth
                            
                            //display task property of each line
                            Text(item.task)
                            // apply a strikethrough and gray color if item is completed
                                .strikethrough(item.isCompleted, color: .primary)
                                .foregroundColor(item.isCompleted ? .gray : .primary)
                        } // end HStack
                        .padding(.vertical, 4)
                    } // END foreeach
                    .onDelete(perform: deleteItems)
                } // end list
                
            }  // end of VStack
            .navigationTitle("To Do List")
            .toolbar {
                // adds the edit button to top right for task deletion
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
            }
        } // End of navigation view
        
        
}
    
    
    private func addItem() {
        // guard against empty tasks
        guard !newTaskName.isEmpty else { return }
        
        withAnimation {
            // create a new item using the text from the stored state variable
            let newItem = Item(task: newTaskName, creationDate: Date())
            modelContext.insert(newItem)
            
            //clear text field after adding an item
            newTaskName = ""
        }
    }
    
    
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(items[index])
            }
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Item.self, inMemory: true)
}
