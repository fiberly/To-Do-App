//
//  Item.swift
//  To Do
//
//  Created by Daniel Barton on 9/21/25.
//

import Foundation
import SwiftData

@Model
final class Item {
  //  var timestamp: Date
    var task: String
    var creationDate: Date
    var isCompleted: Bool
    
    init(task: String, creationDate: Date) {
    //    self.timestamp = timestamp
        self.task = task
        self.creationDate = creationDate
        self.isCompleted = false
    }
}
